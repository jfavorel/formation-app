import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import RegisterForm from "./components/RegisterForm";
import AdminDashboard from "./components/AdminDashboard";
import AdminLogin from "./components/AdminLogin";

function App() {
  return (
    <Router>
      <nav className="navbar navbar-expand navbar-light bg-light px-3">
        <Link to="/" className="navbar-brand">🏠 Accueil</Link>
        <Link to="/admin" className="nav-link">👨‍💼 Admin</Link>
        <Link to="/login" className="nav-link">🔐 Connexion</Link>
      </nav>
      <Routes>
        <Route path="/" element={<RegisterForm />} />
        <Route path="/login" element={<AdminLogin />} />
        <Route path="/admin" element={<AdminDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
