import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function AdminLogin() {
  const [credentials, setCredentials] = useState({ username: "", password: "" });
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", credentials);
      if (res.data.success) navigate("/admin");
    } catch {
      alert("Identifiants incorrects");
    }
  };

  return (
    <div className="container mt-5">
      <h3>🔐 Connexion Admin</h3>
      <form onSubmit={handleLogin}>
        <input className="form-control mb-2" placeholder="Nom d'utilisateur"
          onChange={e => setCredentials({ ...credentials, username: e.target.value })} />
        <input type="password" className="form-control mb-2" placeholder="Mot de passe"
          onChange={e => setCredentials({ ...credentials, password: e.target.value })} />
        <button className="btn btn-success">Se connecter</button>
      </form>
    </div>
  );
}

export default AdminLogin;