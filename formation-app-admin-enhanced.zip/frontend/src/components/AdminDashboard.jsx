import { useEffect, useState } from "react";
import axios from "axios";

function AdminDashboard() {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState("");

  const fetchUsers = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/users");
      setUsers(res.data);
    } catch (err) {
      setError("Erreur de chargement !");
    }
  };

  const deleteUser = async (id) => {
    if (!window.confirm("Supprimer cet utilisateur ?")) return;
    try {
      await axios.delete(`http://localhost:5000/api/users/${id}`);
      setUsers(users.filter((u) => u.id !== id));
    } catch (err) {
      alert("Erreur lors de la suppression.");
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div className="container mt-4">
      <h2>👨‍🏫 Admin - Inscriptions</h2>
      {error && <div className="alert alert-danger">{error}</div>}

      <table className="table table-bordered table-striped mt-3">
        <thead>
          <tr>
            <th>Nom</th><th>Prénom</th><th>Email</th><th>Formation</th><th>Action</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}>
              <td>{u.lastname}</td>
              <td>{u.firstname}</td>
              <td>{u.email}</td>
              <td>{u.formation}</td>
              <td>
                <button className="btn btn-danger btn-sm" onClick={() => deleteUser(u.id)}>
                  Supprimer
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AdminDashboard;